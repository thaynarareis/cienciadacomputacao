package app;

public class Boneca extends  ProdutoAcabado {
    private String cor;
    private String roupa;

    public Boneca(String nome, float valor, String marca, int qtd, String cor, String roupa){
        
        super.setNome(nome);
        super.setValor(valor);
        super.setMarca(marca);
        super.setQtd(qtd);
        this.setCor(cor);
        this.setRoupa(roupa);
        
    }
    
    public void informacao() {
        System.out.println("Nome: " + super.getNome());
        System.out.println("Preço: " + super.getValor()); 
        System.out.println("Marca: " + super.getMarca());
        System.out.println("qtd Estoque" + super.getQtd());
        System.out.println("Cor da roupa" + this.getCor());
        System.out.println("Roupa " + this.getRoupa());
          
        
    }
    
    
    
    
    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getRoupa() {
        return roupa;
    }

    public void setRoupa(String roupa) {
        this.roupa = roupa;
    }
    
    
    
    
}
