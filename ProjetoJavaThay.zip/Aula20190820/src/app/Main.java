
package app;
//super.setNome(nome);
//        super.setValor(valor);
//        super.setMarca(marca);
 //       super.setQtd(qtd);
 //       this.setCor(cor);
 //       this.setRoupa(roupa);

public class Main {

    public static void main(String[] args) {
        
    Boneca b1 = new Boneca("maria", 25.5f, "estrela", 20, "azul", "vestido");
    
    b1.informacao();
    
        
       //MateriaPrima mp = new MateriaPrima("Laranja");
        
        /***
        System.out.println(mp.getEstoque());
        mp.setEstoque(100);
        System.out.println(mp.getEstoque());
        mp.setEstoque(200);
        System.out.println(mp.getEstoque());
        */
        
        //
        
        //System.out.println(mp.getNome());
        //System.out.println(mp.getEstoque());
        //mp.setNome("Morango");
        //System.out.println(mp.getNome());
        //mp.setEstoque(100);
        //mp.setNome("Banana");
        
        //System.out.println(mp.getEstoque());
        //mp.addQtd(20);
        //System.out.println(mp.getEstoque());
        //mp.addQtd(18);
        //System.out.println(mp.getEstoque());
        //mp.subQtd(25);
        //System.out.println(mp.getEstoque());
        
        //System.out.println("..|end application");
    }
    
}
